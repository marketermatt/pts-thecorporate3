<?php

/**
Plugin Name: The Corporate Shortcodes
Plugin URI: http://pixelthemestudio.ca
Description: Add all the required shortcodes for the theme
Version: 1.0.0
Author: Matt
Author URI: http://www.pixelthemestudio.ca
License: GPL3
*/

// Allows Shortcodes in text widgets
add_filter('widget_text', 'do_shortcode');

// Contact
function contact_form( $atts, $content = null ) {
    extract(shortcode_atts(array(
        'email'      => '',
    ), $atts));

    $out = pts_contact_form($email);

    return $out;
}
add_shortcode('contactform', 'contact_form');


// Read More buttons
function pts_readmore( $atts, $content = null ) {
    extract(shortcode_atts(array(
        'link'      => '#',
    ), $atts));

    $out = "<a class=\"more-link\" href=\"" .$link. "\"><span class=\"readmore\">" .do_shortcode($content). "</span></a>";

    return $out;
}
add_shortcode('readmore', 'pts_readmore');

// Drop cap
function pts_dropcap( $atts, $content = null ) {
    return '<span class="dropcap">' . do_shortcode($content) . '</span>';
}
add_shortcode('dropcap', 'pts_dropcap');


// List Styles
add_shortcode('list_square_grey', 'pts_list_square_grey');

function pts_list_square_grey( $atts, $content = null ) {
    $content = str_replace('<ul>', '<ul class="square1">', do_shortcode($content));
    return $content;
}
add_shortcode('list_square_orange', 'pts_list_square_orange');

function pts_list_square_orange( $atts, $content = null ) {
    $content = str_replace('<ul>', '<ul class="square2">', do_shortcode($content));
    return $content;
}
add_shortcode('list_circle', 'pts_list_circle');
function pts_list_circle( $atts, $content = null ) {
    $content = str_replace('<ul>', '<ul class="circle">', do_shortcode($content));
    return $content;
}
add_shortcode('list_roman', 'pts_list_roman');

function pts_list_roman( $atts, $content = null ) {
    $content = str_replace('<ol>', '<ol class="roman">', do_shortcode($content));
    return $content;
}
add_shortcode('list_alpha', 'pts_list_alpha');

function pts_list_alpha( $atts, $content = null ) {
    $content = str_replace('<ol>', '<ol class="alpha">', do_shortcode($content));
    return $content;
}
add_shortcode('list_zero_decimal', 'pts_zero_decimal');

function pts_zero_decimal( $atts, $content = null ) {
    $content = str_replace('<ol>', '<ol class="zerodecimal">', do_shortcode($content));
    return $content;
}
add_shortcode('list_arrow', 'pts_list_arrow');

function pts_list_arrow( $atts, $content = null ) {
    $content = str_replace('<ul>', '<ul class="arrow">', do_shortcode($content));
    return $content;
}
// Separator divider shadow spacer
function pts_divider( $atts, $content = null ) {
    return '<div class="divider"></div>';
}
add_shortcode('divider', 'pts_divider');

// Column 210
function pts_c210( $atts, $content = null ) {
    return '<div class="columnset2 column5">' . do_shortcode($content) . '</div>';
}
add_shortcode('c210', 'pts_c210');

function pts_c210_last( $atts, $content = null ) {
    return '<div class="columnset2 column5 last">' . do_shortcode($content) . '</div><div class="clearfix"></div>';
}
add_shortcode('c210_last', 'pts_c210_last');

// Column 290
function pts_c290( $atts, $content = null ) {
    return '<div class="columnset3 column4">' . do_shortcode($content) . '</div>';
}
add_shortcode('c290', 'pts_c290');

function pts_c290_last( $atts, $content = null ) {
    return '<div class="columnset3 column4 last">' . do_shortcode($content) . '</div><div class="clearfix"></div>';
}
add_shortcode('c290_last', 'pts_c290_last');

// Column 460
function pts_c460( $atts, $content = null ) {
    return '<div class="columnset4 column3">' . do_shortcode($content) . '</div>';
}
add_shortcode('c460', 'pts_c460');

function pts_c460_last( $atts, $content = null ) {
    return '<div class="columnset4 column3 last">' . do_shortcode($content) . '</div><div class="clearfix"></div>';
}
add_shortcode('c460_last', 'pts_c460_last');

// Column 710
function pts_c710( $atts, $content = null ) {
    return '<div class="columnset5 column2">' . do_shortcode($content) . '</div>';
}
add_shortcode('c710', 'pts_c710');

function pts_c710_last( $atts, $content = null ) {
    return '<div class="columnset5 column2 last">' . do_shortcode($content) . '</div><div class="clearfix"></div>';
}
add_shortcode('c710_last', 'pts_c710_last');

// Column 960
function pts_c960( $atts, $content = null ) {
    return '<div class="columnset6 column1">' . do_shortcode($content) . '</div><div class="clearfix"></div>';
}
add_shortcode('c960', 'pts_c960');